let graficoAmpInstance = null;
let historicoCompleto = [];
let filtroMesSelecionado = "";

const INTERVALO_ATUALIZACAO_MS = 2000;

function movimentar() {
    fetch("movimentar.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            item: document.getElementById("item").value,
            amp: document.getElementById("amp").value,
            tipo: document.getElementById("tipo").value,
            quantidade: document.getElementById("quantidade").value
        })
    })
    .then(r => r.text())
    .then(alert)
    .then(() => location.reload());
}

function escaparHTML(valor) {
    return String(valor ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function obterChaveMes(dataTexto) {
    if (!dataTexto) return "";

    const partes = String(dataTexto).match(/^(\d{2})\/(\d{2})\/(\d{4})/);
    if (!partes) return "";

    const mes = partes[2];
    const ano = partes[3];
    return `${ano}-${mes}`;
}

function formatarMesAno(chaveMes) {
    if (!chaveMes) return "";

    const [ano, mes] = chaveMes.split("-");
    const data = new Date(Number(ano), Number(mes) - 1, 1);

    return data.toLocaleDateString("pt-BR", {
        month: "long",
        year: "numeric"
    });
}

function obterHistoricoFiltrado() {
    if (!filtroMesSelecionado) {
        return historicoCompleto;
    }

    return historicoCompleto.filter(h => obterChaveMes(h.data) === filtroMesSelecionado);
}

function renderizarOpcoesFiltroMes() {
    const select = document.getElementById("filtroMesHistorico");
    if (!select) return;

    const meses = [...new Set(
        historicoCompleto
            .map(h => obterChaveMes(h.data))
            .filter(Boolean)
    )].sort().reverse();

    const filtroAindaExiste = !filtroMesSelecionado || meses.includes(filtroMesSelecionado);
    if (!filtroAindaExiste) {
        filtroMesSelecionado = "";
    }

    select.innerHTML = '<option value="">Todos os meses</option>';

    meses.forEach(chaveMes => {
        const option = document.createElement("option");
        option.value = chaveMes;
        option.textContent = formatarMesAno(chaveMes);
        option.selected = chaveMes === filtroMesSelecionado;
        select.appendChild(option);
    });
}

function renderizarHistorico() {
    const historico = document.getElementById("historico");
    if (!historico) return;

    const dadosFiltrados = obterHistoricoFiltrado();

    if (!dadosFiltrados.length) {
        historico.innerHTML = `
            <div class="history-empty">
                <strong>Nenhuma movimentação encontrada.</strong>
                <span>O histórico foi zerado e novas movimentações aparecerão aqui automaticamente.</span>
            </div>
        `;
        return;
    }

    let html = "<table><thead><tr><th>Item</th><th>Amperes</th><th>Movimento</th><th>Qtd</th><th>Data</th></tr></thead><tbody>";

    dadosFiltrados.slice().reverse().forEach(h => {
        const tipo = h.tipo === "entrada" ? "Entrada" : "Saída";
        const amp = h.amp ? `${escaparHTML(h.amp)}A` : "--";

        html += `<tr>
            <td>${escaparHTML(h.item)}</td>
            <td>${amp}</td>
            <td>${tipo}</td>
            <td>${escaparHTML(h.quantidade)}</td>
            <td>${escaparHTML(h.data)}</td>
        </tr>`;
    });

    html += "</tbody></table>";
    historico.innerHTML = html;
}

function atualizarMetricas(consumo) {
    const valores = Object.values(consumo);
    const totalSaidas = valores.reduce((acc, valor) => acc + valor, 0);
    const media = valores.length ? Math.round(totalSaidas / valores.length) : 0;

    let picoAmp = "--";
    let picoValor = -1;

    Object.entries(consumo).forEach(([amp, valor]) => {
        if (valor > picoValor) {
            picoValor = valor;
            picoAmp = `${amp}A`;
        }
    });

    document.getElementById("metricTotalSaidas").textContent = totalSaidas;
    document.getElementById("metricPicoAmp").textContent = totalSaidas > 0 ? picoAmp : "--";
    document.getElementById("metricMediaAmp").textContent = media;
}

function gerarGrafico(dados = []) {
    const consumo = { "50": 0, "130": 0, "200": 0 };

    dados.forEach(h => {
        if (h.tipo !== "saida" || !h.amp) return;

        const amp = String(h.amp);
        const qtd = parseInt(h.quantidade, 10) || 0;

        if (consumo[amp] !== undefined) {
            consumo[amp] += qtd;
        }
    });

    atualizarMetricas(consumo);

    const canvas = document.getElementById("graficoAmp");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");

    if (graficoAmpInstance) {
        graficoAmpInstance.destroy();
    }

    const gradienteBarras = ctx.createLinearGradient(0, 0, 0, 260);
    gradienteBarras.addColorStop(0, "rgba(13, 110, 253, 0.95)");
    gradienteBarras.addColorStop(1, "rgba(13, 110, 253, 0.25)");

    const gradienteLinha = ctx.createLinearGradient(0, 0, 320, 0);
    gradienteLinha.addColorStop(0, "rgba(15, 23, 42, 0.95)");
    gradienteLinha.addColorStop(1, "rgba(13, 110, 253, 0.95)");

    const areaBackgroundPlugin = {
        id: "areaBackgroundPlugin",
        beforeDraw(chart) {
            const { ctx: chartCtx, chartArea } = chart;
            if (!chartArea) return;

            chartCtx.save();
            const bg = chartCtx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
            bg.addColorStop(0, "rgba(13, 110, 253, 0.08)");
            bg.addColorStop(1, "rgba(255, 255, 255, 0.02)");
            chartCtx.fillStyle = bg;
            chartCtx.fillRect(chartArea.left, chartArea.top, chartArea.right - chartArea.left, chartArea.bottom - chartArea.top);
            chartCtx.restore();
        }
    };

    graficoAmpInstance = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["50A", "130A", "200A"],
            datasets: [
                {
                    type: "bar",
                    label: "Volume por amperagem",
                    data: [consumo["50"], consumo["130"], consumo["200"]],
                    backgroundColor: gradienteBarras,
                    borderColor: "rgba(13, 110, 253, 0.95)",
                    borderWidth: 1,
                    borderRadius: 18,
                    borderSkipped: false,
                    maxBarThickness: 42,
                    categoryPercentage: 0.62,
                    barPercentage: 0.78
                },
                {
                    type: "line",
                    label: "Tendência de consumo",
                    data: [consumo["50"], consumo["130"], consumo["200"]],
                    borderColor: gradienteLinha,
                    backgroundColor: "rgba(13, 110, 253, 0.12)",
                    borderWidth: 3,
                    pointRadius: 5,
                    pointHoverRadius: 6,
                    pointBackgroundColor: "#ffffff",
                    pointBorderColor: "#0d6efd",
                    pointBorderWidth: 3,
                    tension: 0.42,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: "index",
                intersect: false
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: "rgba(15, 23, 42, 0.94)",
                    titleColor: "#fff",
                    bodyColor: "#e2e8f0",
                    displayColors: false,
                    padding: 12,
                    cornerRadius: 14,
                    callbacks: {
                        label(context) {
                            return ` ${context.dataset.label}: ${context.raw}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false,
                        drawBorder: false
                    },
                    border: {
                        display: false
                    },
                    ticks: {
                        color: "#475569",
                        font: {
                            size: 12,
                            weight: "700"
                        }
                    }
                },
                y: {
                    beginAtZero: true,
                    border: {
                        display: false
                    },
                    grid: {
                        color: "rgba(148, 163, 184, 0.18)",
                        drawBorder: false,
                        tickLength: 0
                    },
                    ticks: {
                        color: "#64748b",
                        precision: 0,
                        padding: 10,
                        font: {
                            weight: "600"
                        }
                    }
                }
            }
        },
        plugins: [areaBackgroundPlugin]
    });
}

function atualizarDashboard() {
    fetch(`historico.json?v=${Date.now()}`)
        .then(r => r.json())
        .then(dados => {
            historicoCompleto = Array.isArray(dados) ? dados : [];
            renderizarOpcoesFiltroMes();
            renderizarHistorico();
            gerarGrafico(obterHistoricoFiltrado());
        })
        .catch(() => {
            const historico = document.getElementById("historico");
            if (historico) {
                historico.innerHTML = "<p style='padding:16px'>Não foi possível carregar o histórico.</p>";
            }
            gerarGrafico([]);
        });
}

document.addEventListener("DOMContentLoaded", () => {
    const filtroMes = document.getElementById("filtroMesHistorico");
    const limparFiltro = document.getElementById("limparFiltroHistorico");

    if (filtroMes) {
        filtroMes.addEventListener("change", () => {
            filtroMesSelecionado = filtroMes.value;
            renderizarHistorico();
            gerarGrafico(obterHistoricoFiltrado());
        });
    }

    if (limparFiltro) {
        limparFiltro.addEventListener("click", () => {
            filtroMesSelecionado = "";
            if (filtroMes) filtroMes.value = "";
            renderizarHistorico();
            gerarGrafico(obterHistoricoFiltrado());
        });
    }

    atualizarDashboard();
    setInterval(atualizarDashboard, INTERVALO_ATUALIZACAO_MS);
});
